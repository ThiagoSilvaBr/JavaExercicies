import java.util.ArrayList;

public class Main{
    public static void main(String[] args) {
        Turma turma1 = new Turma();

        turma1.matricularAlunos();
        turma1.listarAlunos();
        turma1.getAlunoNaPosicao(2);
        turma1.removerAluno("Pedro");
        turma1.listarAlunos();
    }
}